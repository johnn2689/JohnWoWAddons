<b><a href="https://github.com/MOUZU/BigWigs"> Return to the Overview </a></b>

<br \><br \>
# Temple of Ahn'Qiraj

## The Prophet Skeram

## Vem, Yauj and Kri

## Battleguard Sartura

## Fankriss the Unyielding

## Viscidus

## Princess Huhuran

## The Twin Emperors

## Ouro the Sandworm

## C'Thun

<br \><br \>
##### Prefix legend
- <b>(100%)</b>  = it's working flawless
- <b>(99%)</b>   = it's working as good as it can be (from my research)
- <b>(QA)</b>    = <b>Q</b>uality <b>A</b>ssurance (need to test its modified state)
- <b>(DG)</b>    = <b>D</b>ata <b>G</b>athering (need to gather more data regarding this matter)
