<b><a href="https://github.com/MOUZU/BigWigs"> Return to the Overview </a></b>

<br \><br \>

# Onyxia's Lair

## Trashmobs

## Onyxia
- <b>(100%)</b> Fear, added a timer for the next Fear with 30s.
- <b>(100%)</b> WarnIcon, Fear icon appears when Ony starts casting Fear
- <b>(QA)</b> WarnIcon, Heart of Fire icon appears when Ony starts casting Deep Breath
- <b>(100%)</b> added locale to trigger combat
- <b>(100%)</b> KTM MasterTarget on Onyxia
- <b>(100%)</b> KTM Reset on Phase 3

<br \><br \>
##### Prefix legend
- <b>(100%)</b>  = it's working flawless
- <b>(99%)</b>   = it's working as good as it can be (from my research)
- <b>(QA)</b>    = <b>Q</b>uality <b>A</b>ssurance (need to test its modified state)
- <b>(DG)</b>    = <b>D</b>ata <b>G</b>athering (need to gather more data regarding this matter)
